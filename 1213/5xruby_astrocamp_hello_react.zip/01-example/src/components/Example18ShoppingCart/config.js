export const PRODUCTS = [
  {
    id: '1',
    img: 'images/cat001.jpg',
    title: '拍拍',
    price: 20,
  },
  {
    id: '2',
    img: 'images/cat002.jpg',
    title: '花花',
    price: 15,
  },
  {
    id: '3',
    img: 'images/cat003.jpg',
    title: '錢錢',
    price: 10,
  },
  {
    id: '4',
    img: 'images/cat004.jpg',
    title: '薪薪',
    price: 8.5,
  },
];
